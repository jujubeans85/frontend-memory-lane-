Memory Lane patch v5
- Nav labels: Collection + Bespoke Lamps
- Old /shop and /gallery redirect to /collection
- Images use assets/placeholder.png by default (so nothing breaks)
- Backgrounds: assets/bg1.jpg, assets/bg2.jpg
- Served from / (GitHub Pages subpath)
